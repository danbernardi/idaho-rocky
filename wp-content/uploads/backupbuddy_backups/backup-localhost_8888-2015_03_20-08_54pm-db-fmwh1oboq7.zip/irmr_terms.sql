CREATE TABLE `irmr_terms` (  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(200) NOT NULL DEFAULT '',  `slug` varchar(200) NOT NULL DEFAULT '',  `term_group` bigint(10) NOT NULL DEFAULT '0',  PRIMARY KEY (`term_id`),  KEY `slug` (`slug`),  KEY `name` (`name`)) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `irmr_terms` DISABLE KEYS */;
INSERT INTO `irmr_terms` VALUES('1', 'Uncategorized', 'uncategorized', '0');
INSERT INTO `irmr_terms` VALUES('2', 'Primary Menu', 'primary-menu', '0');
INSERT INTO `irmr_terms` VALUES('3', 'Footer Menu', 'footer-menu', '0');
INSERT INTO `irmr_terms` VALUES('4', 'Experience Sidenav', 'experience-sidenav', '0');
/*!40000 ALTER TABLE `irmr_terms` ENABLE KEYS */;
